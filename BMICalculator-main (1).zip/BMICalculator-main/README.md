# BMICalculator
Just a normal BMI Calculator with a Slider function, for the user to easily set their values, and also the user has access to manually input their values as well.

*Make sure to put the 'assets' folder in the same place the 'BMI_calc.py' file is.*
